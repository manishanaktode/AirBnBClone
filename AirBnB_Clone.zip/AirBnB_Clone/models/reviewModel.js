const mongoose=require("mongoose");  
const reviewschema=new mongoose.Schema({
    reviewID:{
        type:Number,
        //unique:true,
    },
    heading:String,
    userID:Number,
    propertyID:Number,
    //reviewDate:Date,
    rating:Number,
    description:String
});
module.exports = mongoose.model("reviewsdetails",reviewschema)