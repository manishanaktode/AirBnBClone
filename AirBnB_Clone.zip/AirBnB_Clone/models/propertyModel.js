//const res = require("express/lib/response");
//const propertiesdetails=require("../models/propertyModel");
const mongoose=require("mongoose");    
const propertyschema= mongoose.Schema({
    propertyID:{
        type:Number,
        //unique:true,
    },
    nameofprop:String,
    owner:String,
    city:String,
    state:String,
    country:String,
    pricing:String,
    area:Number,
    rating:Number,
    //images:{
    profilepic:String,
        //gallery:{String}
    gallery1:String,
    gallery2:String,
    gallery3:String,
    gallery4:String,
    //},

    bedrooms:Number,
    bathrooms:Number,
    maxguest:Number,
    description:String,
    //amenities:{
    parking:Boolean,
    wifi:Boolean,
    kitchen:Boolean,
    petsallowed:Boolean,
    workspace:Boolean,

    washingmachine:Boolean,
    balcony:Boolean,
    evcharger:Boolean,
    dryer:Boolean,
    garden:Boolean,

    //breakfast:Boolean,
    //ac:Boolean,
    //fridge:Boolean,
    //smokealarm:Boolean,
    //},
    propertyTags:String
});
//const properties=mongoose.model('propertiesdetails',propertyschema)
module.exports = mongoose.model("propertiesdetails",propertyschema)