
const userschema=new mongoose.Schema({
    user_ID:{
        type:Number,
        unique:true,
    },
    usertype:String,
    username:String,
    gender:String,
    email:String,
    password:String,
    mobileno:String,
    dob:String,
    city:String,
    country:String,
    profilepic:String

})


