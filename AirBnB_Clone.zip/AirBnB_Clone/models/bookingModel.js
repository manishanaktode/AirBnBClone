const mongoose=require("mongoose"); 
const bookingschema=new mongoose.Schema({
    bookingID:{
        type:Number,
        //unique:true,
    },
    bookingdate:Date,
    userID:Number,
    propertyID:Number,
    checkinDate:Date,
    checkountDate:Date,
    noofnights:Number,
    totalprice:Number,
    paymentmethod:String
    
});

module.exports = mongoose.model("bookingdetails",bookingschema)
