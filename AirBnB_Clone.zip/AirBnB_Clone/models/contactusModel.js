const mongoose=require("mongoose");  
const contactusschema=new mongoose.Schema({
    contactID:{
        type:Number,
        //unique:true,
    },
    contactno:String,
    email:String,
    username:String,
    query:String
});
module.exports = mongoose.model("contactusdetails",contactusschema)