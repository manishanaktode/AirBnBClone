const express=require("express");
//const multer=require("multer");
const bodyParser=require("body-parser");
const mongoose=require("mongoose");
const path=require("path");
//const { Router } = require("express");
const router = express.Router();

//app instance
const app=express();

mongoose.connect('mongodb://127.0.0.1:27017/airbnbclone')

const propertyschema=new mongoose.Schema({
    propertyID:{
        type:Number,
        //unique:true,
    },
    nameofprop:String,
    owner:String,
    city:String,
    state:String,
    country:String,
    pricing:String,
    area:Number,
    rating:Number,
    images:{
        profile:String,
        gallery:{String}
    },

    bedrooms:Number,
    bathroom:Number,
    maxguest:Number,
    description:String,
    amenities:{
        parking:Boolean,
        wifi:Boolean,
        breakfast:Boolean,
        ac:Boolean,
        fridge:Boolean,
        kitchen:Boolean,
        smokealarm:Boolean,
        petsallowed:Boolean
    },
    propertyTags:{String}
})
const properties=mongoose.model('propertiesdetails',propertyschema)

const userschema=new mongoose.Schema({
    user_ID:{
        type:Number,
        unique:true,
    },
    usertype:String,
    username:String,
    gender:String,
    email:String,
    password:String,
    mobileno:String,
    dob:String,
    city:String,
    country:String,
    profilepic:String

})


const bookingschema=new mongoose.Schema({
    bookingID:{
        type:Number,
        unique:true,
    },
    bookingdate:Date,
    userID:Number,
    propertyID:Number,
    checkinDate:Date,
    checkountDate:Date,
    noofnights:Number,
    totalprice:Number,
    paymentmethod:String,
    noofrooms:Number
})

const contactusschema=new mongoose.Schema({
    contactID:{
        type:Number,
        unique:true,
    },
    contactno:String,
    email:String,
    username:String,
    query:String
})

const reviewschema=new mongoose.Schema({
    reviewID:{
        type:Number,
        unique:true,
    },
    heading:String,
    userID:Number,
    propertyID:Number,
    reviewDate:Date,
    rating:Number,
    description:String
})


const booking_=mongoose.model('bookingdetails',bookingschema)
const user_=mongoose.model('userdetails',userschema)
const contactus_=mongoose.model('contactusdetails',contactusschema)
const property_=mongoose.model('propertydetails',propertyschema)
const review_=mongoose.model('reviewdetails',reviewschema)

module.exports={user_,booking_,contactus_,property_,review_};

router.get("/login",(req,res)=>{
    console.log("Hello");
    res.sendFile(root_path + "/views/indexnew.html");
});

let userIDnum=1;
router.post("/signup",(req,res)=>{
    console.log(req.body);
    const user_=new user_({
        userID:'user${userIDnum}',
        usertype:req.body.usertype,
        username:req.body.username,
        gender:req.body.username,
        email:req.body.email,
        password:req.body.password,
        mobileno:req.body.mobileno,
        dob:req.body.dob,
        city:req.body.city,
        country:req.body.country,
        profilepic:"null"
    });
userIDnum++;
user_.save((err,result)=>{
    if(err){ 
        console.log(err);
    } else {
        console.log("User added");
    }
});

const cookiedata={
    userID:'user_$(userIDnum)'
};
userIDnum++;
res.cookie("userData",cookiedata);
res.send("User Added To Database");
});

let propertyIDnum=1;
router.post("/registerproperty",(req,res)=>{
    console.log(req.body);
    const property_=new property_({
        propertyID:'user${propertyIDnum}',
        name:req.body.usertype,
        owner:req.body.username,
        city:req.body.username,
        email:req.body.email,
        password:req.body.password,
        mobileno:req.body.mobileno,
        dob:req.body.dob,
        city:req.body.city,
        country:req.body.country,
        pricing:req.body.pricing,
        area:req.body.area,
        rating:req.body.rating,
        images:{
            profile:req.body.profile,
            gallery:req.body.gallery
        },
    
        bedrooms:req.body.bedrooms,
        bathroom:req.body.bathroom,
        maxguest:req.body.maxguest,
        description:req.body.parking.description,
        amenities:{
            parking:req.body.parking,
            wifi:req.body.wifi,
            breakfast:req.body.breakfast,
            ac:req.body.ac,
            fridge:req.body.fridge,
            kitchen:req.body.kitchen,
            smokealarm:Boreq.body.smokealarm,
            petsallowed:req.body.petsallowed
        },
        
    propertyTags:req.body.tags.split(","),
});
propertyIDnum++;
property_.save((err,result)=>{
    if(err){ 
        console.log(err);
    } else {
        console.log("Property Booked");
    }
});
res.send("property added to database");
});

let bookingIDnum=1;
router.post("/booking",(req,res)=>{
console.log(req.body);
const booking_=new booking_({
bookingID:'user${bookingIDnum}',
    bookingdate:req.body.bookingdate,
    userID:req.body.userID,
    propertyID:req.body.propertyID,
    checkinDate:Dareq.body.emacheckinDate,
    checkountDate:req.body.checkountDate,
    noofnights:req.body.noofnights,
    totalprice:req.body.totalprice,
    paymentmethod:req.body.paymentmethod,
    noofrooms:req.body.noofrooms
});
bookingIDnum++;
booking_.save((err,result) => {
    if(err){ 
        console.log(err);
    } else {
        console.log("Property Booked");
    }

res.send("Property Information Saved in databse");
});
});

let contactusIDnum=1;
router.post("/contactus",(req,res)=>{
console.log(req.body);
const contactus_=new contactus_({
    contactID:'user${contactusIDnum}',
    contactno:req.body.contactno,
    email:req.body.email,
    username:req.body.username,
    query:req.body.query
});
contactusIDnum++;
contactus_.save((err,result) => {
    if(err){ 
        console.log(err);
    } else {
        console.log("Contact information saved");
    }
});
res.send("Contact Information Saved in databse");
});

let reviewIDnum=1;
router.post("/review",(req,res)=>{
console.log(req.body);
const review_=new contactus_({
    reviewID:'user${reviewIDnum}',
    heading:Streq.body.heading,
    userID:req.body.userID,
    propertyID:req.body.propertyID,
    reviewDate:req.body.reviewDate,
    rating:req.body.rating,
    description:req.body.description
});
reviewIDnum++;
review_.save((err,result)=>{
    if(err){ 
        console.log(err);
    } else {
        console.log("Review saved");
    }
});
res.send("Review Information Saved in databse");
});

app.get('/',(req,res)=>{
    res.sendFile(__dirname + "/Views/index.html");
})

app.listen(5000, ()=>{
    console.log("server started");
})

