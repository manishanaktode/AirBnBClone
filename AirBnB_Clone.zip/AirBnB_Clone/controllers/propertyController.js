const res=require("express/lib/response");
const propertymaster=require("../models/propertyModel");
const insertproperty = async(req,res)=>{
    let propertyIDnum=1;
    try{
        propertyIDnum++;
        const property=new propertymaster({
                propertyID:propertyIDnum,
                name:req.body.name,
                owner:req.body.owner,
                city:req.body.city,
                country:req.body.country,
                pricing:req.body.pricing,
                area:req.body.area,
                rating:req.body.rating,
                //images:{
                profilepic:req.body.profilepic,
                gallery1:req.body.gallery1,
                gallery2:req.body.gallery2,
                gallery3:req.body.gallery3,
                gallery4:req.body.gallery4,
                //},
            
                bedrooms:req.body.bedrooms,
                bathrooms:req.body.bathrooms,
                maxguest:req.body.maxguest,
                description:req.body.description,
                propertytag:req.body.propertytag,
                //amenities:{
                parking:req.body.parking,
                wifi:req.body.wifi,
                workspace:req.body.workspace,
                kitchen:req.body.kitchen,
                petsallowed:req.body.petsallowed,

                //breakfast:req.body.breakfast,
                //ac:req.body.ac,
                //fridge:req.body.fridge,  
                //smokealarm:req.body.smokealarm,
                //smokealarm:req.body.smokealarm
                
                washingmachine:req.body.washingmachine,  
                balcony:req.body.balcony,
                evcharger:req.body.evcharger,
                dryer:req.body.dryer,
                garden:req.body.garden

                
                //},
        });

        const result=await property.save();
        res.send("Property Save Successfully" +result);
        
    } catch(error){
        res.send(error.message);
    }

}
module.exports={
    insertproperty
}