const res=require("express/lib/response");
const contactus=require("../models/contactusModel");
const insertcontactus = async(req,res)=>{
    let contactusIDnum=1;
    try{
        contactusIDnum++;
        const contactus1=new contactus({
                contactID:contactusIDnum,
                contactno:req.body.contactno,
                username:req.body.username,
                email:req.body.email,
                query:req.body.query
                
        });

        const result=await contactus1.save();
        res.send("Contact Information Save Successfully" +result);
        
    } catch(error){
        res.send(error.message);
    }

}
module.exports={
    insertcontactus
}