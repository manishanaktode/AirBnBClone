const res=require("express/lib/response");
const review=require("../models/reviewModel");
const insertreview = async(req,res)=>{
    let reviewIDnum=1;
    try{
        reviewIDnum++;
        const review_=new review({
                reviewID:reviewIDnum,
                heading:req.body.heading,
                userid:1,//req.body.userid,
                propertyid:1,//req.body.propertyid,
                //reviewDate:req.body.reviewDate,
                rating:req.body.rating,
                description:req.body.description
                
        });

        const result=await review_.save();
        res.send("Review Save Successfully" +result);
        
    } catch(error){
        res.send(error.message);
    }

}
module.exports={
    insertreview
}