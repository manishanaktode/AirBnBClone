const res=require("express/lib/response");
const booking=require("../models/bookingModel");

const date = require('date-and-time');
const now  =  new Date();
const date1 = date.format(now,'YYMMDDHHmmss');

const insertbooking = async(req,res)=>{
    //let bookingIDnum=2;
    try{
        //bookingIDnum++;
        const booking_=new booking({
                bookingID:date1,
                bookingdate:req.body.bookingdate,
                userID:1,//req.body.userID,
                propertyID:1,//req.body.bookingdate,
                checkinDate:req.body.checkinDate, 
                checkountDate:req.body.checkountDate,
                noofnights:req.body.noofnights,
                totalprice:req.body.totalprice,
                paymentmethod:req.body.paymentmethod,
                noofrooms:req.body.noofrooms      
        });

        const result=await booking_.save();
        res.send("Property Booked Successfully" +result);
        
    } catch(error){
        res.send(error.message);
    }

}
module.exports={
    insertbooking
}