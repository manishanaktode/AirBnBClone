const express=require("express");
const multer=require("multer");
const mongoose=require("mongoose");
mongoose.connect('mongodb://127.0.0.1:27017/airbnbclone')

const path=require("path");
const { Router } = require("express");
const router = express.Router();

//app instance

const app=express();

// PROPERTY MASTER
const propmasterRoute=require("./routes/propertymasterRoute");
app.use('/',propmasterRoute.propmasterRoute);

// CONTACT US
const contactusRoute=require("./routes/contactusRoute");
app.use('/',contactusRoute.contactusRoute);
// REVIEW 
const reviewRoute=require("./routes/reviewRoute");
app.use('/',reviewRoute.reviewRoute);
// BOOKING
const bookingRoute=require("./routes/bookingRoute");
app.use('/',bookingRoute.bookingRoute);

app.get('/',(req,res)=>{
    res.sendFile(__dirname + "/views/indexnew.html");
})

app.listen(4000,function(){
    console.log("server started");
});



