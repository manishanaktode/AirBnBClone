const express=require("express");
const reviewRoute=express();

const bodyParser=require("body-parser");

reviewRoute.use(bodyParser.json());
reviewRoute.use(bodyParser.urlencoded({extended:true}));

reviewRoute.set('view engine','pug');
reviewRoute.set('views','./views');

const reviewController=require("../controllers/reviewController");

reviewRoute.get('/review',function(req,res){
    res.render("review");
});

reviewRoute.post('/review',reviewController.insertreview);

module.exports={
    reviewRoute
}

