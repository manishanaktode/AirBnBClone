const express=require("express");
const bookingRoute=express();

const bodyParser=require("body-parser");

bookingRoute.use(bodyParser.json());
bookingRoute.use(bodyParser.urlencoded({extended:true}));

bookingRoute.set('view engine','pug');
bookingRoute.set('views','./views');

const bookingController=require("../controllers/bookingController");

bookingRoute.get('/booking',function(req,res){
    res.render("booking");
});

bookingRoute.post('/booking',bookingController.insertbooking);

module.exports={
    bookingRoute
}

