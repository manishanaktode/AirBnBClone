//const mongoose=require("mongoose");
//mongoose.connect('mongodb://127.0.0.1:27017/airbnbclone');

const express=require("express");
const propmasterRoute=express();

const bodyParser=require("body-parser");

propmasterRoute.use(bodyParser.json());
propmasterRoute.use(bodyParser.urlencoded({extended:true}));

propmasterRoute.set ('view engine','pug');
propmasterRoute.set ('views','./views');

const propmastController=require("../controllers/propertyController");

propmasterRoute.get('/propertymaster',function(req,res){
    res.render("propertyMaster");
});

propmasterRoute.post('/propertymaster',propmastController.insertproperty);

module.exports={
    propmasterRoute
}

//const multer=require("multer");
//const property_=require("./controllers/propertyController");





//router.get("/login",(req,res)=>{
//    console.log("Hello");
//    res.sendFile(root_path + "/Views/indexnew.html");
//});