const express=require("express");
const contactusRoute=express();

const bodyParser=require("body-parser");

contactusRoute.use(bodyParser.json());
contactusRoute.use(bodyParser.urlencoded({extended:true}));

contactusRoute.set ('view engine','pug');
contactusRoute.set ('views','./views');

const contactusController=require("../controllers/contactusController");

contactusRoute.get('/contactus',function(req,res){
    res.render("contactus");
});

contactusRoute.post('/contactus',contactusController.insertcontactus);

module.exports={
    contactusRoute
}

